package com.example.refapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
