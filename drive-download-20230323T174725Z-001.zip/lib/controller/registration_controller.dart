import 'package:get/get.dart';

import '../model/User_model.dart';

class RegistrationController extends GetxController {
  var user = User(email: '', password: '', referralCode: '', name: '').obs;

  void register() {
    // Implement registration logic here
  }

  void updateEmail(String email) {
    user.update((val) {
      val!.email = email;
    });
  }

  void updatePassword(String password) {
    user.update((val) {
      val!.password = password;
    });
  }

  void updateReferralCode(String referralCode) {
    user.update((val) {
      val!.referralCode = referralCode;
    });
  }
}
