import 'dart:math';

import 'package:get/get.dart';
import 'package:refapp/model/User_model.dart';

import '../model/User_model.dart';

class AuthController extends GetxController {
  final Rx<User?> user = Rx<User?>(null);

  void signUp(String name, String email, String password) {
    // Generate a random referral code
    final String referralCode = _generateReferralCode();


    user.value = User(
      name: name,
      email: email,
      password: password,
      referralCode: referralCode,
    );
  }

  void login(String email, String password, String referralCode, String name) {

    user.value = User(email: email, password: password, referralCode: referralCode, name:name);
  }

  String _generateReferralCode() {
    final Random random = Random();
    final String alphabet = '0123456789LMNOPQRSTUVWXYZ';
    final int referralCodeLength = 2;

    String referralCode = '';

    for (int i = 0; i < referralCodeLength; i++) {
      referralCode += alphabet[random.nextInt(alphabet.length)];
    }

    return referralCode;
  }
}
