import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  var _RegistrationController;
  var isLoading = false.obs;

  void login() async {
    if (emailController.text.isEmpty || passwordController.text.isEmpty) {
      Get.snackbar('Error', 'Please enter your email and password.');
      return;
    }

    isLoading.value = true;

    // replace this with your own login logic
    await Future.delayed(Duration(seconds: 2));

    isLoading.value = false;


    if (_RegistrationController.isRegistered.value) {
      Get.offAllNamed('/home');
    } else {
      // show error message
      Get.snackbar('Error', 'Please register before logging in',
          backgroundColor: Colors.red,
          colorText: Colors.white,
          snackPosition: SnackPosition.BOTTOM);


      Get.offAllNamed('/home');
    }
  }
}