import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:refapp/controller/registration_controller.dart';

import '../controller/registration_controller.dart';
import 'loginscreen.dart';

class RegistrationScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final RegistrationController _registrationController =
  Get.put(RegistrationController());

  @override
  Widget build(BuildContext context) {
    var height = Get.height;
    var width = Get.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Registration'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(

                decoration: InputDecoration(labelText: 'Email' ,

                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  return null;
                },
                onChanged: (value) {
                  _registrationController.updateEmail(value);
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  return null;
                },
                onChanged: (value) {
                  _registrationController.updatePassword(value);
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Referral Code (optional)'),
                onChanged: (value) {
                  _registrationController.updateReferralCode(value);
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _registrationController.register();
                    print("Form validated");

                    Get.to(() => LoginScreen());

                  }
                },
                child: Text('Register'),

              ),
            ],
          ),
        ),
      ),
    );
  }
}
