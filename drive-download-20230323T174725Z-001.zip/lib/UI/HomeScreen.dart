import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:refapp/UI/Homescreen.dart';
import 'package:refapp/UI/registartionscreen.dart';
import 'package:refapp/controller/auth_controller.dart';

import '../controller/auth_controller.dart';

class HomeScreen extends StatelessWidget {
  final AuthController authController = Get.find();

  @override
  Widget build(BuildContext context) {
    var height = Get.height;
    var width = Get.width;
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (authController.user.value != null) ...[
                Text('Welcome ${authController.user.value!.name}!'),
                SizedBox(height: 16),
                Text('Referral code: ${authController.user.value!.referralCode}'),
              ],
              if (authController.user.value == null) ...[
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Loading user data...'),
              ],
              ElevatedButton(
                child: Text('create account'),
                onPressed: () {
                  Get.to(() => RegistrationScreen());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
