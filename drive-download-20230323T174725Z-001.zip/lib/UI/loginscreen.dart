import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:refapp/UI/registartionscreen.dart';

import '../controller/login_controller.dart';

class LoginScreen extends StatelessWidget {
  final LoginController _loginController = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    var height = Get.height;
    var width = Get.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(hintText: 'Email'),
              controller: _loginController.emailController,
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(hintText: 'Password'),
              controller: _loginController.passwordController,
              obscureText: true,
            ),
            SizedBox(height: 16),
            Obx(
                  () =>
                  ElevatedButton(
                    child: _loginController.isLoading.value
                        ? CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    )
                        : Text('Login'),
                    onPressed: _loginController.isLoading.value
                        ? null
                        : _loginController.login,
                  ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              child: Text('Sign Up'),
              onPressed: () {
                Get.to(() => RegistrationScreen());
              },
            ),
          ],
        ),
      ),
    );
  }}