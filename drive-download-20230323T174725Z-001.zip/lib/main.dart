import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:refapp/controller/auth_controller.dart';
import 'package:refapp/controller/login_controller.dart';
import 'package:refapp/controller/registration_controller.dart';
 import 'package:refapp/UI/HomeScreen.dart';
 import 'package:refapp/UI/loginscreen.dart';
 import 'package:refapp/UI/registartionscreen.dart';

void main() {

   Get.put(AuthController());
   Get.put(LoginController());
   Get.put(RegistrationController());
  runApp(MyApp());

}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // var height = Get.height;
    // var width = Get.width;
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'referal system',
      initialRoute: '/',
      defaultTransition: Transition.fade,
       getPages: [
         GetPage(
           name: '/login',
          page: () => LoginScreen(),
           transition: Transition.fade,
       ),
        GetPage(
           name: '/registration',
           page: () => RegistrationScreen(),
           transition: Transition.fade,
       ),
        GetPage(
          name: '/home',
           page: () => HomeScreen(),
           transition: Transition.fade,
         ),
       ],
    );
  }
}
