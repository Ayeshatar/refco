class User {
  String email;

  String password;
  String? name;
  String referralCode;

  User({required this.email, required this.password, required this.referralCode, required String name});
}
